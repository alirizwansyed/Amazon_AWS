# importing the multiprocessing module
import multiprocessing
import pandas as pd
import math as m
from requests_html import HTMLSession
import requests
from bs4 import BeautifulSoup
import urllib.parse
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from datetime import datetime
import os
from collections import Counter
from random import randint
from time import sleep

DateString = datetime.now().strftime("%Y%m%d-%I%M%S%p")

def search_keyword_from_url(search_lst,search_rnk_lst,search_url_lst,pc,opfilename,captchafile):
    products_num_lst = []
    counter=0
    headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0", "Accept-Encoding":"gzip, deflate", "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "DNT":"1","Connection":"close", "Upgrade-Insecure-Requests":"1"}
    for i in search_url_lst:
        if counter%2==0:
            sleep(randint(0,10)/100)
            r = requests.get(i, headers=headers)
        else:
            sleep(randint(11,20)/100)
            html_sess =HTMLSession()
            r = html_sess.get(i)

        try:
            soup = BeautifulSoup(r.text, 'html.parser')
            result = soup.find('div',{'class':'a-section a-spacing-small a-spacing-top-small'}).get_text(strip=True)
            products_num_lst.append(result.split(" results ")[0])
            print("process counter :",pc,i)
        except Exception as E:
            products_num_lst.append("0")
            print("process counter :",pc)
            print("Captcha Exception",i)
            
        counter=counter+1
    
    # Creation of Output file
    df=pd.DataFrame()  
    df['Rank']=search_rnk_lst
    df['Keywords']=search_lst
    df['Number Of Products']=products_num_lst
    df['URL']=search_url_lst
    #df = df[df['Number Of Products'] != '0']
    if os.path.exists(opfilename):
      df.to_csv(opfilename,index=False,header=False,mode='a')
    else:
      df.to_csv(opfilename,index=False)

def search_generate_url(pc,df,opfilename,captchafile):
    search_lst=list(df['Search Term'])
    search_rank=list(df['Search Frequency Rank'])
    search_url=[]
    for i in search_lst:
      s = urllib.parse.quote_plus(i)
      s_2='https://www.amazon.in/s?k='+s
      search_url.append(s_2)
    print("Called for process number:",pc,'with lenght of ',len(df))
    search_keyword_from_url(search_lst,search_rank,search_url,pc,opfilename,captchafile)

if __name__ == "__main__":
    opfilename='C:/Users/sali1045/Desktop/AmazonSearchTerm/Step2_4_Output_ExtractRank'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+'.csv'
    captchafile='C:/Users/sali1045/Desktop/AmazonSearchTerm/Step2_4_Output_ExtractRank_captcha_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+'.csv'
    ipfilename=r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Step1_4_Output_Filtered_Keywords20210723-122025AM - Copy.csv"

    #ipfilename=r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Step1_4_Output_Filtered_Keywords20210723-122025AM.csv"
    while True:
        print("Entered while loop for ",ipfilename)
        df=pd.read_csv(ipfilename)
        if len(df) ==0:
            break
        strfile_len = len(str(len(df)))
        print(strfile_len)
        inc_val = m.floor(len(df)/strfile_len)
        c = 0
        c_100 = c + inc_val
        list_process = []
        process_counter=1
        while True:
            
            if c_100 < len(df):
                try:
                    print('C Value: ',c,' :c_100 value: ',c_100)
                    p1 = multiprocessing.Process(target=search_generate_url, args=(process_counter,df[c:c_100],opfilename,captchafile, ))
                    c=c_100
                    c_100 = c_100 + inc_val
                    list_process.append(p1)
                    process_counter=process_counter+1
                    p1.start()
                except Exception as E:
                    print('################Exception: Exception inside While Loop in Main: ',E)
            else:
                try:
                    print('C Value: ',c,' :c_100 value: ',c_100)
                    p1 = multiprocessing.Process(target=search_generate_url, args=(process_counter,df[c:c_100],opfilename,captchafile, ))
                    c=c_100
                    c_100 = c_100 + inc_val
                    list_process.append(p1)
                    process_counter=process_counter+1
                    p1.start()
                except Exception as E:
                    print('################Exception: Exception inside While Loop in Main: ',E)
                break
        
        print(list_process)
        for lp in list_process:
            lp.join()

        df=pd.read_csv(opfilename)
        df1= df[df['Number Of Products'] != '0']
        df1.to_csv(opfilename,index=False)
        df = df[df['Number Of Products'] == '0']

        captcha_df=pd.DataFrame()        
        captcha_df['Search Frequency Rank']=list(df['Rank'])
        captcha_df['Search Term']=list(df['Keywords'])
        captcha_df['URL']=list(df['URL'])
        print("Captcha dataframe length ",len(captcha_df))
        captcha_df.to_csv(captchafile,index=False)
            
        ipfilename=captchafile
        print("Changed input file")
        
