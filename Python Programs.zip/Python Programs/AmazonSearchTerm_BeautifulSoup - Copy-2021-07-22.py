# https://stackoverflow.com/questions/52719378/failed-to-find-valid-data-directory-mysql-generic-binary-installion
# https://www.dezyre.com/recipes/connect-mysql-python-and-import-csv-file-into-mysql-and-create-table

from requests_html import HTMLSession
from bs4 import BeautifulSoup
import pandas as pd
import urllib.parse
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from datetime import datetime
import os
from collections import Counter
from random import randint
from time import sleep


DateString = datetime.now().strftime("%Y%m%d-%I%M%S%p")

def search_keyword_from_url(search_lst,search_rnk_lst,search_url_lst,opfilename):
    products_num_lst = []
    for i in search_url_lst:
        sleep(randint(1,9)/100)
        html_sess =HTMLSession()
        r = html_sess.get(i)
        #r.html.render(sleep=1)
        soup = BeautifulSoup(r.text, 'html.parser')
        print(i)
        try:
            result = soup.find('div',{'class':'a-section a-spacing-small a-spacing-top-small'}).get_text(strip=True)
            products_num_lst.append(result.split(" results ")[0])
        except Exception as E:
            products_num_lst.append("0")
            print(soup)
            
    df=pd.DataFrame()  
    df['Rank']=search_rnk_lst
    df['Keywords']=search_lst
    df['Number Of Products']=products_num_lst
    df['URL']=search_url_lst
    if os.path.exists(opfilename):  
      df.to_csv(opfilename,index=False,mode='a')
    else:
      df.to_csv(opfilename,index=False)

#Main
df=pd.read_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Step4_Input_forPythonScript20210722-030805PM.csv")
search_lst=df['Search Term']
search_rank=df['Search Frequency Rank']
search_url=[]
for i in search_lst:
  s = urllib.parse.quote_plus(i)
  s_2='https://www.amazon.in/s?k='+s
  search_url.append(s_2)
opfilename='C:/Users/sali1045/Desktop/AmazonSearchTerm/June_Soup_SearchTerm'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+'.csv'
c=0
c_100=c+10
while True:
  if c_100 < len(search_lst):
    search_keyword_from_url(search_lst[c:c_100],search_rank[c:c_100],search_url[c:c_100],opfilename)
    c=c_100
    c_100=c+10
  else:
    search_keyword_from_url(search_lst[c:len(search_lst)],search_rank[c:len(search_lst)],search_url[c:len(search_lst)],opfilename)
    break
