from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from selenium.webdriver.common.action_chains import ActionChains
from datetime import datetime
from selenium.webdriver.ie.options import Options
from selenium.webdriver.common.keys import Keys
import os
from pathlib import Path
#paths = sorted(Path(dirpath).iterdir(), key=os.path.getmtime)

driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', False)
driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
#driver.get("https://uhgazure.sharepoint.com/sites/orxtech/pfm/Fixed%20Capacity%20Billing%20FCB/Forms/AllItems.aspx")
driver.get("https://uhgazure.sharepoint.com/sites/orxtech/pfm/_layouts/15/download.aspx?UniqueId=340cd9a7%2De273%2D40e5%2Db2dd%2D603f6958ca71")
time.sleep(6)
driver.find_element_by_xpath('//*[@id="i0116"]').send_keys('rizwan.syedali@optum.com')
driver.find_element_by_xpath('//*[@id="idSIButton9"]').click()
time.sleep(30)
paths = sorted(Path("C:\\Users\\sali1045\\Downloads").iterdir(), key=os.path.getmtime)

print(paths[-1])
os.system('copy "'+str(paths[-1])+'" "C:\\Users\\sali1045\\Documents\\test.xlsx"')
#df.to_csv(r'C:\Users\sali1045\Downloads\SharePoint_OptumRxPortfolio_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv",index=False,encoding='utf-8')
driver.close()
