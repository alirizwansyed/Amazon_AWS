import utils as ut
import cx_Oracle
from sqlalchemy import types, create_engine
import pandas as pd
import time
import urllib3
# from datetime import datetime
import datetime
import sys
import os
from pandas import DataFrame
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pyspark import SparkConf
from pyspark.sql import SparkSession, Column
from pyspark.sql.functions import lit, col, to_timestamp, coalesce
from pyspark.sql.types import *
from pyspark.sql.functions import min, max
from pyspark.sql import SQLContext

sparkSession = None
sc = None


SRC_SYSTEM_CD = 'BILLING_GWBC'

class GeneralException(Exception):

    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message

def init_spark():

    print("initiating spark session")
    global sparkSession, sc
    app_name = "jdbc_test.py"
    master = "local[*]"
    print("initiating spark configuration")
    conf = SparkConf().setAppName(app_name).setMaster(master).set('spark.executor.memory', '2g')
    print("completed spark session")
    # Get path for Oracle jdbc driver
    print("initiating getting jdbc_jars")
    jdbc_jar = get_key_value('/jdbc/Oracle/jar')    
    if jdbc_jar:
        conf.set('spark.jars', jdbc_jar)  # set the spark.jars
        print('Using jdbc driver {}'.format(jdbc_jar))
    else:
        raise GeneralException('Could not get path to JDBC driver from config')
    print("after getting jdbc_jars")
    sparkSession = SparkSession.builder.config(conf=conf).getOrCreate()
    print("after spark session built")
    sc = sparkSession.sparkContext
    print("after spark context built")

#Loading to Oracle from dataframe

def get_key_value(key):
    #print(" in start of get_key_value")
    value = ut.getinipath(key, None)
    if not value:
        print('Could not find value for key {}'.format(key))
        return None  
    #print(" in end of get_key_value")
    return value


def get_next_sequence():
    #print("in get_next_sequence")
    sql = 'select DATAHUB_HDS.E1P_BC_SEQ.nextval from dual'    
    #print(sql)
    seq = g_cursor.execute(sql).fetchone()[0]    
    #print('completed get_next_sequence '+str(seq))
    return seq

def get_cycle_id():

    #print("in get_cycle_id")
    sql = """select cycle_id from datahub_md.etl_cycle where src_system_cd = :src_system_cd and cycle_status = 'Running'"""
    #print(sql)
    result = g_cursor.execute(sql, {'src_system_cd': SRC_SYSTEM_CD}).fetchall()
    #print(result)
    if len(result) == 0:
        raise GeneralException("Could not get cycle_id from src_system_cd '{}' - check DATAHUB_MD.ETL_CYCLE".format(SRC_SYSTEM_CD))
    else:
        print("end of get_cycle_id "+str(result[0][0]))
        return int(result[0][0])

#Loading to Oracle from dataframe
def cols_missing_fun(df,table_name):   

    ##### derive the existing columns
    #print("deriving missing columns")
    columns_existing = []
    try:
        
        sql_stmt="select LISTAGG((COLUMN_NAME),',') WITHIN GROUP (ORDER BY TABLE_NAME) from  all_tab_columns  WHERE OWNER='DATAHUB_HDS' AND TABLE_NAME='"+table_name.split('.')[1]+"'"
        g_cursor.execute(sql_stmt)
        df1 = DataFrame(g_cursor.fetchall())
        columns_existing=str(df1.iloc[0,0]).strip(' ')
        columns_existing=columns_existing.split(',')            
        
    except Exception as e:
        print(str(e))

    ##### derive the existing columns

    ##### dataframe columns    
    df_columns=list(df.columns)
    ##### dataframe columns
    
    columns_existing= [x.upper().strip(' ') for x in columns_existing]
    df_columns= [x.upper().strip(' ') for x in df_columns] 
    cols_missing=list(set(df_columns) - set(columns_existing))
    return cols_missing


def load_insert_records(df,table_name):
    
    tableDF=df
    jsonDF = df.withColumn('ETL_CREATE_DTS', lit(datetime.datetime.now()))\
            .withColumn('etl_cycle_id', lit(get_cycle_id()))\
            .withColumn('ETL_ROW_EFF_DTS', lit(datetime.datetime.now()))\
            .withColumn('ETL_ROW_TERM_DTS',lit(datetime.datetime(9999,12,31,9,48,45,486832)))\
            .withColumn('ETL_CURRENT_ROW_IND',lit('Y'))\
            .withColumn('ETL_KEY',lit(get_next_sequence()))\
            .withColumn('ETL_CHANGE_TYPE_CD',lit('I'))\
            .withColumn('ETL_UPDATE_DTS',lit(datetime.datetime.now()))\
            .withColumn('HEADER__OPERATION',lit('I'))\
            .withColumn('HEADER__TRANSACTION_ID',lit('-99'))
    
    df_cols=jsonDF.columns
    #print(df_cols)
    #print("completed getting jsonDF columns")
    missing_cols=cols_missing_fun(jsonDF,table_name)
    #print(missing_cols)
    #print("collected missing columns")
    #cols_missing=missing_cols
    #print("trying to send email")
    # try:
    #     col_mis_check = 0
    #     for c in cols_missing:
    #         if str(c).startswith('__S3') or str(c).startswith('ETL_'):
    #             pass
    #         else:
    #             col_mis_check = 1
    #     if col_mis_check == 1:
    #         print("Missing columns in oracle table-" + table_name, "Columns missing in table " + str(cols_missing) + " .There is Discrepency Between Columns in EDDS Vs HDS Table.Please investigate and take necessary action")
    # except:
    #     print("unable to send email")

    select_cols=[]

    for dfci in df_cols:
        f=0
        for mci in missing_cols:
            if mci.upper().strip(' ')==dfci.upper().strip(' '):
                f=1
                break
        if f==0:
            select_cols.append(dfci)
    jsonDF = jsonDF.select(*select_cols)
    #print("after formatting tableDF")
    #timestamp_cols=get_timestamp_cols(table_name)
    #print("start of formatting time stamp columns")
    #print(timestamp_cols)
    print("start of loading spark df")
    # Write to table
    jsonDF.write.jdbc(url=url, table=table_name, mode='append', properties=properties)

# Give table name with HDS schema
def load_update_records(df,table_name,primary_key_col):
    
    print("in load_update_records")
    for dfui in df:        
        try:
            ETL_ROW_EFF_DTS  = "TO_TIMESTAMP('" + str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')) + "','YYYY-MM-DD HH24:MI:SS.FF')"
            primary_key_val=dfui
            end_date=ETL_ROW_EFF_DTS
            sql_stmt="Update "+table_name+" set ETL_ROW_TERM_DTS="+end_date+",ETL_CURRENT_ROW_IND='N',ETL_CHANGE_TYPE_CD='U',ETL_UPDATE_DTS="+end_date+" where "+primary_key_col+"="+str(primary_key_val)+" and ETL_CURRENT_ROW_IND='Y'"    
            sql_stmt=sql_stmt.replace('"TO_TIMESTAMP','TO_TIMESTAMP').replace('HH24:MI:SS.FF\')"', 'HH24:MI:SS.FF\')').replace(', None',',null').replace('None,','null,')
            g_cursor.execute(sql_stmt)
            
        except Exception as e:
            print(dfui)
            print(str(e))

    print("completed updating the records")
        

def check_args(argv):
    print("check args function started")
    if len(argv) == 3:
        print("check args function completed")
        return argv[1], argv[2]    
    else:
        print('Usage: Load_BC_HDS_DELTA_LOAD.py TABLE_NAME Primary_key_column')
        sys.exit(1)

def load_to_audit(table_name, ins_recds_cnt, update_recds_cnt,source_recs):

    print("In load_to_audit")
    SOURCE_SCHEMA='DATAHUB_EDDS'
    SOURCE_TABLE_NAME=table_name
    TARGET_TABLE_NAME=table_name
    # LOAD_TS="TO_TIMESTAMP('"+str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'))+"','YYYY-MM-DD HH24:MI:SS.FF')"
    TARGET_SCHEMA='DATAHUB_HDS'    
    ETL_CYCLE_ID= get_cycle_id()
    TOTAL_NEW_INSERTED_RECORDS = ins_recds_cnt
    TOTAL_UPD_INSERTED_RECORDS = update_recds_cnt
    TOTAL_UPDATED_RECORDS = update_recds_cnt
    TOTAL_SOURCE_RECORDS = source_recs

    df_audit=pd.DataFrame()

    df_audit['SOURCE_SCHEMA']=[SOURCE_SCHEMA]
    df_audit['SOURCE_TABLE_NAME']=[SOURCE_TABLE_NAME]
    df_audit['TARGET_TABLE_NAME']=[TARGET_TABLE_NAME]
    # df_audit['LOAD_TS']=[LOAD_TS]
    df_audit['TARGET_SCHEMA']=[TARGET_SCHEMA]
    df_audit['ETL_CYCLE_ID']=[ETL_CYCLE_ID]
    df_audit['TOTAL_NEW_INSERTED_RECORDS'] = [TOTAL_NEW_INSERTED_RECORDS]
    df_audit['TOTAL_UPD_INSERTED_RECORDS'] = [TOTAL_UPD_INSERTED_RECORDS]
    df_audit['TOTAL_UPDATED_RECORDS'] = [TOTAL_UPDATED_RECORDS]
    df_audit['TOTAL_SOURCE_RECORDS'] = [TOTAL_SOURCE_RECORDS]

    #print(df_audit)
    #print("converting pandas dataframe to spark dataframe")
    df_sp = sparkSession.createDataFrame(df_audit)
    #print("completed converting pandas dataframe to spark dataframe")
    df_sp = df_sp.withColumn('LOAD_TS', lit(datetime.datetime.now()))
    #print(df_sp)
    df_sp.write.jdbc(url=url, table='DATAHUB_HDS.EDDS_BC_HDS_AUDIT', mode='append', properties=properties)
    print("Inserted record into audit table"+"\n")

    

def main():

    print("script run started")
    global g_connection, g_cursor
    init_spark()
    global v_updatedtm
    v_updatedtm = ""
    try:
        g_connection = cx_Oracle.connect(ut.getdblogin())
        print("Connection established successfully")
    except Exception as e:
        print("Error during establishment of connection="+str(e))        

    try:
        g_cursor = g_connection.cursor()
        print("cursor established successfully")
    except Exception as e:
        print("Error during establishment of cursor="+str(e))

        

    global engine,scd2_succ_recds_cnt,scd2_fail_recds_cnt

    scd2_succ_recds_cnt=0
    scd2_fail_recds_cnt=0

    engine=""
    # table_name="EDDS_BC_POLICY"
    # primary_key_col="ID"
    print("Check args collecting required info")
    table_name, primary_key_col = check_args(sys.argv)
    print("Check args completed collecting required info")
    print("started deriving v_updatedtm")
    table_name, primary_key_col = check_args(sys.argv)
    if table_name.upper().startswith("EDDS_BCTL") or table_name.upper() == 'EDDS_BC_CONTACTADDRESS':
        v_updatedtm = 'HEADER__TIMESTAMP'
    else:
        v_updatedtm = 'UPDATETIME'
    #print(v_updatedtm)
    #print("completed deriving v_updatedtm")
    #print(v_updatedtm)
    ## creating oracle engine
    print("creating oracle engine started")
    try:
        engine=ut.getengine()
    except Exception as e:
        print(str(e))
    print("creating oracle engine completed")
    global url
    global properties
    print("started generating url")
    url = get_key_value('/jdbc/Oracle/url')  
    print("generated url is"+str(url))  
    if not url:
        raise GeneralException('Could not get JDBC URL from config')
    print('Using JDBC URL {}'.format(url))
    properties = {'user': 'datahub', 'password': 'DATAHUB', 'driver': 'oracle.jdbc.OracleDriver', 'isolationLevel': 'READ_COMMITTED'}
    print("properites of jdbc will be set to "+str(properties))
    
    print("trying to retrieve insert dataframe")
    sql_stmt='SELECT SRC.* '
    sql_stmt = sql_stmt + ' FROM (SELECT SRC.* FROM (select SRC.*,RANK () OVER (PARTITION BY ID ORDER BY '+v_updatedtm+' DESC) RNK   FROM  DATAHUB_EDDS.' + table_name + ' SRC) SRC WHERE SRC.RNK=1)'
    sql_stmt=sql_stmt+' SRC LEFT JOIN DATAHUB_HDS.'+table_name+' TGT ON SRC.'+primary_key_col+' = TGT.'+primary_key_col    
    sql_stmt=sql_stmt+" WHERE TGT."+primary_key_col+" IS NULL"
    sql_stmt="("+sql_stmt+")"
    print("Insert ids extracting Query:")
    #print(sql_stmt)

    insert_df = sparkSession.read.jdbc(url=url, table=sql_stmt, properties=properties)
    ins_recds_cnt = insert_df.count()
    
    print("completed reading df_insert_rows")

    if insert_df.count() > 0:                
        load_insert_records(insert_df,'DATAHUB_HDS.'+table_name)
    print("completed inserting the records")
    
    sql_stmt='SELECT SRC.'+primary_key_col+' AS SRC_ID'
    sql_stmt=sql_stmt+' FROM (SELECT SRC.* FROM (select SRC.*,RANK () OVER (PARTITION BY ID ORDER BY '+v_updatedtm+' DESC) RNK   FROM  DATAHUB_EDDS.'+table_name+' SRC) SRC WHERE SRC.RNK=1)'
    sql_stmt=sql_stmt+' SRC LEFT JOIN DATAHUB_HDS.'+table_name+' TGT ON SRC.'+primary_key_col+' = TGT.'+primary_key_col
    sql_stmt=sql_stmt+" WHERE TGT."+primary_key_col+" IS NOT NULL AND SRC.ETL_CHECKSUM!=TGT.ETL_CHECKSUM AND TGT.ETL_CURRENT_ROW_IND ='Y'"

    print("Update ids extracting Query:")
    #print(sql_stmt)
    
    df_update_rows = pd.read_sql_query(sql_stmt, engine)
    df_update_rows.columns = [x.upper().strip(' ') for x in  df_update_rows.columns]
    update_ids=list(df_update_rows['SRC_ID'])
    print("completed upating the records")

    sql_stmt='SELECT SRC.* '
    sql_stmt=sql_stmt+' FROM (SELECT SRC.* FROM (select SRC.*,RANK () OVER (PARTITION BY ID ORDER BY '+v_updatedtm+' DESC) RNK   FROM  DATAHUB_EDDS.'+table_name+' SRC) SRC WHERE SRC.RNK=1)'
    sql_stmt=sql_stmt+' SRC LEFT JOIN DATAHUB_HDS.'+table_name+' TGT ON SRC.'+primary_key_col+' = TGT.'+primary_key_col
    sql_stmt=sql_stmt+" WHERE TGT."+primary_key_col+" IS NOT NULL AND SRC.ETL_CHECKSUM!=TGT.ETL_CHECKSUM AND TGT.ETL_CURRENT_ROW_IND ='Y'"
    sql_stmt="("+sql_stmt+")"
    print("Update ids extracting Query:")
    #print(sql_stmt)
    
    update_df=sparkSession.read.jdbc(url=url, table=sql_stmt, properties=properties)
    update_recds_cnt = update_df.count()
    load_update_records(update_ids, 'DATAHUB_HDS.' + table_name, primary_key_col)
    print("completed reading df_update_rows")
    if update_df.count() > 0:
        load_insert_records(update_df,'DATAHUB_HDS.'+table_name)
    print("completed inserting the updated records")

    # ins_recds_cnt = insert_df.count()
    # update_recds_cnt = update_df.count()
    source_recs = ins_recds_cnt + update_recds_cnt
    print(ins_recds_cnt)
    print(update_recds_cnt)
    print(source_recs)
    load_to_audit(table_name, ins_recds_cnt, update_recds_cnt, source_recs)    
    print("load to audit table completed")
    g_connection.commit()
    print("g_connection.commit completed")
    if g_cursor:
        g_cursor.close()
        print("g_cursor.close completed")
    if g_connection:
        g_connection.close()
        print("g_connection.close completed")


main()

