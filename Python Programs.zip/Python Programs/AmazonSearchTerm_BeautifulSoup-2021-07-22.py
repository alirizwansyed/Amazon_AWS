# https://stackoverflow.com/questions/52719378/failed-to-find-valid-data-directory-mysql-generic-binary-installion
# https://www.dezyre.com/recipes/connect-mysql-python-and-import-csv-file-into-mysql-and-create-table

from requests_html import HTMLSession
import requests
from bs4 import BeautifulSoup
import pandas as pd
import urllib.parse
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from datetime import datetime
import os
from collections import Counter
from random import randint
from time import sleep


DateString = datetime.now().strftime("%Y%m%d-%I%M%S%p")

def search_keyword_from_url(search_lst,search_rnk_lst,search_url_lst,opfilename,captchafile):
    products_num_lst = []
    counter=0
    headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0", "Accept-Encoding":"gzip, deflate", "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "DNT":"1","Connection":"close", "Upgrade-Insecure-Requests":"1"}
    for i in search_url_lst:
        if counter%2==0:
            sleep(randint(0,10)/100)
            r = requests.get(i, headers=headers)
        else:
            sleep(randint(11,20)/100)
            html_sess =HTMLSession()
            r = html_sess.get(i)

        #headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0", "Accept-Encoding":"gzip, deflate", "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "DNT":"1","Connection":"close", "Upgrade-Insecure-Requests":"1"}
        #r = requests.get(i, headers=headers)

        #html_sess =HTMLSession()
        #r = html_sess.get(i)
        
        try:
            soup = BeautifulSoup(r.text, 'html.parser')
            result = soup.find('div',{'class':'a-section a-spacing-small a-spacing-top-small'}).get_text(strip=True)
            products_num_lst.append(result.split(" results ")[0])
            print(i)
        except Exception as E:
            products_num_lst.append("0")
            print("Captcha Exception",i)
            captcha_search_lst.append(search_lst[counter])
            captcha_search_rnk_lst.append(search_rnk_lst[counter])
            captcha_search_url_lst.append(i)
        counter=counter+1
        
    # Creation of Captcha file
    captcha_df=pd.DataFrame()
    captcha_df['Search Frequency Rank']=captcha_search_rnk_lst
    captcha_df['Search Term']=captcha_search_lst
    captcha_df['URL']=captcha_search_url_lst
    captcha_df.to_csv(captchafile,index=False)
    
    # Creation of Output file
    df=pd.DataFrame()  
    df['Rank']=search_rnk_lst
    df['Keywords']=search_lst
    df['Number Of Products']=products_num_lst
    df['URL']=search_url_lst
    df = df[df['Number Of Products'] != '0']
    if os.path.exists(opfilename):
      df.to_csv(opfilename,index=False,header=False,mode='a')
    else:
      df.to_csv(opfilename,index=False)


#Main
opfilename='C:/Users/sali1045/Desktop/AmazonSearchTerm/June_Soup_SearchTerm'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+'.csv'
captcha_filename='C:/Users/sali1045/Desktop/AmazonSearchTerm/June_captcha_Soup_SearchTerm'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+'.csv'
ipfilename=r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Step4_Input_forPythonScript20210722-055940PM.csv"
captcha_search_lst=[]
captcha_search_rnk_lst=[]
captcha_search_url_lst=[]

while True:
    df=pd.read_csv(ipfilename)
    if len(df) == 0:
        break
    search_lst=list(df['Search Term'])
    search_rank=list(df['Search Frequency Rank'])
    search_url=[]
    for i in search_lst:
      s = urllib.parse.quote_plus(i)
      s_2='https://www.amazon.in/s?k='+s
      search_url.append(s_2)

    c=0
    c_100=c+100
    while True:
      if c_100 < len(search_lst):
        try:
            search_keyword_from_url(search_lst[c:c_100],search_rank[c:c_100],search_url[c:c_100],opfilename,captcha_filename)
            c=c_100
            c_100=c+100
        except Exception as E:
            print('################Exception: Exception inside While Loop in Main: ',E)
      else:
        search_keyword_from_url(search_lst[c:len(search_lst)],search_rank[c:len(search_lst)],search_url[c:len(search_lst)],opfilename,captcha_filename)
        break
    print("Starting to re run the Captcha Exception list file")
    ipfilename=captcha_filename
    captcha_search_lst=[]
    captcha_search_rnk_lst=[]
    captcha_search_url_lst=[]
    sleep(15)
