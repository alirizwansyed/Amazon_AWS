import pandas as pd
from datetime import datetime as dt
DateString = dt.now().strftime("%Y%m%d-%I%M%S%p")
###### Step 1 Local Data Preparation. Pick the columns "Search Term" and "Search Frequency Rank" from Amazon Search Report######
df_input = pd.read_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\AmazonSearchTermMay21.csv", encoding ='ISO-8859-1')
print("Starting to Read Amazon Search Term file")
df_input_step1 = df_input[['Search Term','Search Frequency Rank']]
print("Count of Rows in Amazon Search Term file: ", len(df_input_step1))

###### Step 2 Remove Bad Search Terms ######
df_exclusion_list = pd.read_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Exclusing_List.csv")
print("Starting to Read Exclusing list file")
print("Exclusing list word count: ", len(df_exclusion_list))
df_input_step2 = df_input_step1[df_input_step1['Search Term'].str.contains('|'.join(df_exclusion_list['Exclusion_List']),case=False)==False]
print("Count of Exlusing words: ",len(df_input_step2))
df_input_step2.to_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Step2_RemoveBadTerms"+DateString+".csv", index=False)

###### Step 3 Remove Last Batch Search Terms which has HIGH Competition ######
try:
    df_HighCompetition = pd.read_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Output_PythonScript.csv")
    print("Starting to Read High Competition list file")
    df_HighCompetition=df_HighCompetition[(df_HighCompetition["Number Of Products"] != "Number Of Products")]
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("results for","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("result for","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("1-48 of ","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("1-16 of ","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("over","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("Number Of Products","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace(",","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace("1-24 of ","")
    df_HighCompetition["Number Of Products"] = df_HighCompetition["Number Of Products"].str.replace(" ","")

    df_HighCompetition["Number Of Products"] = pd.to_numeric(df_HighCompetition["Number Of Products"], errors='coerce')
    df_HighCompetition = df_HighCompetition[df_HighCompetition['Number Of Products'] > 500]
    df_LowCompetition = df_HighCompetition[df_HighCompetition['Number Of Products'] < 500]
    DateString = dt.now().strftime("%Y%m%d-%I%M%S%p")
    print("Writing the High/ Low Competition files")
    #df_HighCompetition.to_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Output_HighCompetition_"+DateString+".csv", index=False)
    #df_LowCompetition.to_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Output_LowCompetition_"+DateString+".csv", index=False)

    df_input_step3 = df_input_step2[df_input_step2['Search Term'].str.contains('|'.join(df_HighCompetition['Keywords']),case=False)==False]
    df_input_step3.to_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Step3_RemoveHighCompetition"+DateString+".csv", index=False)
except:
    print("Stet 3: Except Block. High Competition file is not available")
    df_input_step3 = df_input_step2
    df_input_step3.to_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Step3_RemoveHighCompetition"+DateString+".csv", index=False)

###### Step 4 Lookup for Category keywords ######
try:
    print("Starting to read file")
    df_CategoryKeywords = pd.read_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Category_Keywords.csv")
    print("Reading file successful")
    print("Started reading Category Keyword file, count of rows in Category Keyword are: ",len(df_CategoryKeywords))
    df_input_step4 = df_input_step3[df_input_step3['Search Term'].str.contains('|'.join(df_CategoryKeywords['Category_Keywords']),case=False)==True]
    print("Number of Rows after doing vlookup with Category Keywords are: ",len(df_input_step4))
    df_input_step4.to_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Step4_Input_forPythonScript"+DateString+".csv", index=False)
except:
    print("Step 4: Except Block. Category Keyword doesnt exist")
    df_input_step4 = df_input_step3
    df_input_step4.to_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Step4_Input_forPythonScript"+DateString+".csv", index=False)
# ###### Step 5 Remove 1 letter Search Terms ######
# print("Starting to count number of letters")
# #number_of_words = df_input_step3["Search Term"].map(lambda x: len(x))
# number_of_words = df_input_step3["Search Term"].str.count(' ').add(1).value_counts(sort=False)
# df_input_step3["number_of_words"] = number_of_words
# df_input_step4 = df_input_step3
# print(df_input_step4.head())
# df_input_step3.to_csv(r"C:\Users\sali1045\Desktop\AmazonSearchTerm\Input_forPythonScript"+DateString+".csv", index=False)
