from pydomo import Domo
import pandas
from datetime import datetime
import os
import time
import smtplib


CLIENT_ID = 'fd5ecefb-5ce2-4664-93f7-5d59709ec011'
CLIENT_SECRET = '5e048e311276840da96857d4481a523b0dfadae7aebbc57254a4642f14295fc2'
API_HOST = 'api.domo.com'
domo = Domo(CLIENT_ID, CLIENT_SECRET, api_host=API_HOST)

dt_str=str(datetime.now().strftime('%Y%m%d%H%M%S'))

## Download a Dataset from Domo

current_openings_federated_data = domo.ds_get('d9e11273-f012-47a8-a964-e6b0a987d8f2')
time.sleep(120)
df_current_openings = pandas.DataFrame(data=current_openings_federated_data)
print(len(df_current_openings))


# Create a new data set in Domo with the result, the return value is the data set id of the new data set.
#current_openings_daily_refresh_data_ds =

domo.ds_create(df_current_openings,'Python | Current Openings v4','Python | Current Openings v4 2021.PI.18.S4')

#current_openings_daily_refresh_data_ds_update = domo.ds_update(current_openings_daily_refresh_data_ds,current_openings_federated_data)

time.sleep(60)
