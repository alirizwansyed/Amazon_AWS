
import configparser

def read_ini(file_path,key):
    config = configparser.ConfigParser()
    config.read(file_path)
    for section in config.sections():
        return config[section][key]
