import os
from shutil import copyfile
from datetime import datetime
import datetime as dt
import shutil

thisdirs = [r'c:\users\sali1045\desktop',r'c:\users\sali1045\documents',r'c:\users\sali1045\downloads']
prev_days=5
now = dt.datetime.now()
ago = now-dt.timedelta(days=prev_days)

def python_files_copy():
    c=0
    # r=root, d=directories, f = files
    for thisdir in thisdirs:
        for r, d, f in os.walk(thisdir):
            for file in f:
                if file.endswith(".py"):   
                    src_file = os.path.join(r, file)
                    st = os.stat(src_file)    
                    mtime = dt.datetime.fromtimestamp(st.st_mtime)
                    mt=mtime
                    mt=str(mt)
                    if True:   
                        c=c+1      
                        try:
                            destpath=str(r).replace(r"c:\users\sali1045",r"c:\users\sali1045\desktop\python programs os - "+str(datetime.now().strftime('%m%d')))
                            if not os.path.exists(destpath):
                                os.makedirs(destpath)                
                            file_temp=file
                            file_temp=file_temp.split('.')[0]+"-"+str(mt.split(' ')[0])+"."+file_temp.split('.')[1]
                            dest_file=os.path.join(destpath, file_temp)                            
                            copy_cmd='copy "'+src_file+'" '+'"'+dest_file+'"'
                            # print(copy_cmd)
                            try:
                                os.system(copy_cmd)   
                            except Exception as e:
                                print(e)
                        except Exception as e:
                            print(os.path.join(r, file))
                            print(str(e))
    if c>0:
        output_filename=r"c:\users\sali1045\desktop\python programs os - "+str(datetime.now().strftime('%m%d'))
        dir_name=r"c:\users\sali1045\desktop\python programs os - "+str(datetime.now().strftime('%m%d'))              
        shutil.make_archive(output_filename, 'zip', dir_name)

def powershell_files_copy():
    # r=root, d=directories, f = files
    c=0
    for thisdir in thisdirs:
        for r, d, f in os.walk(thisdir):
            for file in f:
                
                if file.endswith(".ps1"): 
                    src_file = os.path.join(r, file)
                    st = os.stat(src_file)    
                    mtime = dt.datetime.fromtimestamp(st.st_mtime)
                    mt=mtime
                    mt=str(mt)
                    if True:   
                        c=c+1      
                        try:
                            destpath=str(r).replace(r"c:\users\sali1045",r"c:\users\sali1045\desktop\ps scripts os - "+str(datetime.now().strftime('%m%d')))
                            if not os.path.exists(destpath):
                                os.makedirs(destpath)                
                            # copyfile(os.path.join(r, file),os.path.join(destpath, file))
                            file_temp=file
                            file_temp=file_temp.split('.')[0]+"-"+str(mt.split(' ')[0])+"."+file_temp.split('.')[1]
                            dest_file=os.path.join(destpath, file_temp)                            
                            copy_cmd='copy "'+src_file+'" '+'"'+dest_file+'"'            
                            # print(copy_cmd)
                            try:
                                os.system(copy_cmd)   
                            except Exception as e:
                                print(e)
                        except Exception as e:
                            print(os.path.join(r, file))
                            print(str(e))
    if c > 0:
        output_filename=r"c:\users\sali1045\desktop\ps scripts os - "+str(datetime.now().strftime('%m%d'))
        dir_name=r"c:\users\sali1045\desktop\ps scripts os - "+str(datetime.now().strftime('%m%d'))              
        shutil.make_archive(output_filename, 'zip', dir_name)

python_files_copy()
powershell_files_copy()