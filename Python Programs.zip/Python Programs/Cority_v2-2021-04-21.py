from pydomo import Domo
import pandas
from datetime import datetime
import os
import time
import smtplib


CLIENT_ID = '1c42f21c-5029-45c6-8393-5f8c48c50327'
CLIENT_SECRET = '13466d70aec77f70041cae3a3af6791327fd6da0f9a2c862028336587bd08102'
API_HOST = 'api.domo.com'
domo = Domo(CLIENT_ID, CLIENT_SECRET, api_host=API_HOST)

dt_str=str(datetime.now().strftime('%Y%m%d%H%M%S'))

Email_Message = ''
Success_Email_Message='Output list of files with EMP ID: '
Export_Files_Count = 0

try:
    print('Starting to read the input files')
    ## Step 1: We need to update the input Datasets
    DD_Inp_Dir = "Z:/divvydose (DD)/DOMO/Input/"
    PC_Inp_Dir = "Z:/PolyClinic (PC)/DOMO/Input/"
    OMG_Inp_Dir = "Z:/OregonMedGroup (OMG)/DOMO/Input/"
    GNO_Inp_Dir = "Z:/genoa (GNO)/DOMO/Input/"
    SS_Inp_Dir = "Z:/SmartSheet (SS)/domo/Input-UHG Covid/"
    
    #SSD_Inp_Dir = "Z:/SmartSheet (SS)/DOMO/Input-UHG Declination/"
    SCA_Inp_Dir = "Z:/Surgical Care Affiliates (SCA)/DOMO/Input/"
    #SCAD_Inp_Dir = "Z:/Surgical Care Affiliates (SCA)/DOMO/Declination Input/"

    print("Assigning constants to know if input file is available or not")
    DD_Err=0
    PC_Err=0
    OMG_Err=0
    GNO_Err=0
    SS_Err=0
    SCA_Err=0

    #SSD_Err=0
    #SCAD_Err=0
    
## PC File handling Start
    try:
        print('Starting to read PC Input file')
        df_PC = pandas.read_excel(PC_Inp_Dir+[f for f in os.listdir(PC_Inp_Dir) if os.path.isfile(os.path.join(PC_Inp_Dir , f))][0])
        print('Updating Polyclinic Dataset from input file')
        domo.ds_update('86e96151-f4ef-4bac-acf7-0bbbf8a34fa4',df_PC)
        PC_Inp_FileName_lst = os.listdir(PC_Inp_Dir)
        PC_Inp_FileName = list(filter(lambda x: 'xlsx' in x, PC_Inp_FileName_lst))
        
    except Exception as E:
        if 'list index out of range' in str(E):
            PC_Err = 2
        else:
            Email_Message = Email_Message + '\n\n PC Input file handling Error: \n\n' + str(E)
            PC_Err = 1
            print('======================NOT FOUND: Input file for PC on NAS Drive======================')
## SS File handling Start
    try:
        print('Starting to read SS Input file')
        df_SS = pandas.read_csv(SS_Inp_Dir+[f for f in os.listdir(SS_Inp_Dir) if os.path.isfile(os.path.join(SS_Inp_Dir , f))][0])
        print('Updated SS Dataset from input file')
        domo.ds_update('4fb72ae8-2626-4417-bfeb-4972f18f0168',df_SS)
        SS_Inp_FileName_lst= os.listdir(SS_Inp_Dir)
        SS_Inp_FileName = list(filter(lambda x: 'csv' in x, SS_Inp_FileName_lst))
    except Exception as E:
        if 'list index out of range' in str(E):
            SS_Err = 2
        else:
            Email_Message = Email_Message + '\n\n SS Input file handling Error: \n\n' + str(E)
            SS_Err = 1
            print('======================NOT FOUND: Input file for SS on NAS Drive======================')
## OMG File handling Start
    try:
        print('Starting to read OMG Input file')
        df_OMG = pandas.read_excel(OMG_Inp_Dir+[f for f in os.listdir(OMG_Inp_Dir) if os.path.isfile(os.path.join(OMG_Inp_Dir , f))][0])
        domo.ds_update('9bbef66c-2555-4e2c-942d-c3df4acc6631',df_OMG)
        print('Updating OMG Dataset from input file')
        OMG_Inp_FileName_lst = os.listdir(OMG_Inp_Dir)
        OMG_Inp_FileName  = list(filter(lambda x: 'xlsx' in x, OMG_Inp_FileName_lst))
    except Exception as E:
        if 'list index out of range' in str(E):
            OMG_Err = 2
        else:
            Email_Message = Email_Message + '\n\n OMG Input file handling Error: \n\n' + str(E)
            OMG_Err = 1
            print('======================NOT FOUND: Input file for OMG on NAS Drive======================')
## GNO File handling Start
    try:
        print('Starting to read GNO Input file')
        df_GNO = pandas.read_excel(GNO_Inp_Dir+[f for f in os.listdir(GNO_Inp_Dir) if os.path.isfile(os.path.join(GNO_Inp_Dir , f))][0])
        domo.ds_update('a6c6725b-0bfd-4cb4-990e-fcc4a45b852b',df_GNO)
        print('Updating GNO Dataset from input file')
        GNO_Inp_FileName_lst = os.listdir(GNO_Inp_Dir)
        GNO_Inp_FileName  = list(filter(lambda x: 'xlsx' in x, GNO_Inp_FileName_lst))
    except Exception as E:
        Email_Message = Email_Message + '\n\n GNO Input file handling Error: \n\n' + str(E)
        GNO_Err = 1
        print('======================NOT FOUND: Input file for GNO on NAS Drive======================')
## DD File handling Start
    try:
        print('Starting to read DD Input file')
        df_DD = pandas.read_excel(DD_Inp_Dir+[f for f in os.listdir(DD_Inp_Dir) if os.path.isfile(os.path.join(DD_Inp_Dir , f))][0])
        domo.ds_update('d777d788-a6bf-40d9-b48a-26e4287b5c04',df_DD)
        print('Updating DD Dataset from input file')
        DD_Inp_FileName_lst = os.listdir(DD_Inp_Dir)
        DD_Inp_FileName = list(filter(lambda x: 'xlsx' in x, DD_Inp_FileName_lst))
    except Exception as E:
        if 'list index out of range' in str(E):
            DD_Err = 2
        else:
            Email_Message = Email_Message + '\n\n DD Input file handling Error: \n\n' + str(E)
            DD_Err = 1
            print('======================NOT FOUND: Input file for DD on NAS Drive======================')

## SCA File handling Start
    try:
         print('Starting to read SCA Input file')
         df_SCA = pandas.read_excel(SCA_Inp_Dir+[f for f in os.listdir(SCA_Inp_Dir) if os.path.isfile(os.path.join(SCA_Inp_Dir , f))][0])
         domo.ds_update('3921fa50-7d73-40b6-934c-31e442ff8e28',df_SCA)
         print('Updating SCA Dataset from input file')
         SCA_Inp_FileName_lst = os.listdir(SCA_Inp_Dir)
         SCA_Inp_FileName = list(filter(lambda x: 'xlsx' in x, SCA_Inp_FileName_lst))
    except Exception as E:
        if 'list index out of range' in str(E):
            SCA_Err = 2
        else:
             Email_Message = Email_Message + '\n\n SCA Input file handling Error: \n\n' + str(E)
             SCA_Err = 1
             print('======================NOT FOUND: Input file for SCA on NAS Drive======================')
###
# ## SCAD File handling Start
#     try:
#         print('Starting to read SCAD Input file')
#         df_SCAD = pandas.read_excel(SCAD_Inp_Dir+[f for f in os.listdir(SCAD_Inp_Dir) if os.path.isfile(os.path.join(SCAD_Inp_Dir , f))][0])
#         domo.ds_update('694e73aa-fadb-4af3-95a4-83c3ff12aa14',df_SCAD)
#         print('Updating SCAD Dataset from input file')
#         SCAD_Inp_FileName_lst = os.listdir(SCAD_Inp_Dir)
#         SCAD_Inp_FileName = list(filter(lambda x: 'xlsx' in x, SCAD_Inp_FileName_lst))
#     except Exception as E:
#         if 'list index out of range' in str(E):
#            SCAD_Err = 2
#         else:
#             Email_Message = Email_Message + '\n\n SCAD Input file handling Error: \n\n' + str(E)
#             SCAD_Err = 1
#             print('======================NOT FOUND: Input file for SCAD on NAS Drive======================')
# ## SSD File handling Start
#     try:
#         print('Starting to read SSD Input file')
#         df_SSD = pandas.read_csv(SSD_Inp_Dir+[f for f in os.listdir(SSD_Inp_Dir) if os.path.isfile(os.path.join(SSD_Inp_Dir , f))][0])
#         domo.ds_update('65e421d9-d842-4420-b263-e944d1fb4f01',df_SSD)
#         print('Updating SSD Dataset from input file')
#         SSD_Inp_FileName_lst = os.listdir(SSD_Inp_Dir)
#         SSD_Inp_FileName  = list(filter(lambda x: 'csv' in x, SSD_Inp_FileName_lst))
#     except Exception as E:
#         if 'list index out of range' in str(E):
#            SSD_Err = 2
#         else:
#             Email_Message = Email_Message + '\n\n SSD Input file handling Error: \n\n' + str(E)
#             SSD_Err = 1
#             print('======================NOT FOUND: Input file for SSD on NAS Drive======================')
###    

    print('On Hold for 4 mins for batch to complete')
    time.sleep(2)
    
    try:
        print('Exporting Datasets from DOMO to NAS Drive')
        PC_id='ce648bd6-259c-418c-a84c-aa857117dbdb'
        if PC_Err == 0:
            PC_Output='Z:\PolyClinic (PC)\DOMO\output\DOMO_'+PC_Inp_FileName[0]
            output = domo.ds_get(PC_id)
            output.to_excel(PC_Output,index=False)
            print('======================Exporting PC file complete====================')
            Export_Files_Count = Export_Files_Count + 1
            Success_Email_Message = Success_Email_Message + '\n\n'+'DOMO_' + PC_Inp_FileName[0]
        if PC_Err == 2:
            Export_Files_Count = Export_Files_Count + 1
    except Exception as E:
        Email_Message = Email_Message + '\n\n PC Output file Export Error: \n\n' + str(E)
        print('Issue while exporting PC Dataset from DOMO to NAS Drive')
        print('======================FAILED EXPORTING PC file ====================')
    try:
        SS_id='193a95af-1f66-4dc5-9841-09404e764ff6'
        if SS_Err == 0:
            SS_Output='Z:\SmartSheet (SS)\DOMO\output\DOMO_'+SS_Inp_FileName[0]
            output = domo.ds_get(SS_id)
            output.to_csv(SS_Output,index=False)
            print('======================Exporting SS file complete====================')
            Export_Files_Count = Export_Files_Count + 1
            Success_Email_Message = Success_Email_Message + '\n\n'+'DOMO_' + SS_Inp_FileName[0]
        if SS_Err == 2:
            Export_Files_Count = Export_Files_Count + 1
    except Exception as E:
        Email_Message = Email_Message + '\n\n SS Output file Export Error: \n\n' + str(E)
        print('Issue while exporting SS Dataset from DOMO to NAS Drive')
        print(str(E))
        print('======================FAILED EXPORTING SS file ====================')

    try:
        OMG_id='e21ad8cd-2947-47c5-a23f-28602d7db910'
        if OMG_Err == 0:
            OMG_Output='Z:\OregonMedGroup (OMG)\DOMO\output\DOMO_'+OMG_Inp_FileName[0]
            output = domo.ds_get(OMG_id)
            output.to_excel(OMG_Output,index=False)
            print('======================Exporting OMG file complete====================')
            Export_Files_Count = Export_Files_Count + 1
            Success_Email_Message = Success_Email_Message + '\n\n'+'DOMO_' + OMG_Inp_FileName[0]
        if OMG_Err == 2:
            Export_Files_Count = Export_Files_Count + 1
    except Exception as E:
        Email_Message = Email_Message + '\n\n OMG Output file Export Error: \n\n' + str(E)
        print('Issue while exporting OMG Dataset from DOMO to NAS Drive')
        print('======================FAILED EXPORTING OMG file ====================')

    try:
        GNO_id='59e0f7f6-a9e4-415b-aae3-5c32ae2f4eac' #updated
        if GNO_Err == 0:
            GNO_Output='Z:\genoa (GNO)\DOMO\output\DOMO_'+GNO_Inp_FileName[0]
            output = domo.ds_get(GNO_id)
            output.to_excel(GNO_Output,index=False)
            print('======================Exporting GNO file complete====================')
            Export_Files_Count = Export_Files_Count + 1
            Success_Email_Message = Success_Email_Message + '\n\n'+'DOMO_' + GNO_Inp_FileName[0]
        if GNO_Err == 2:
            Export_Files_Count = Export_Files_Count + 1
    except Exception as E:
        Email_Message = Email_Message + '\n\n GNO Output file Export Error: \n\n' + str(E)
        print('Issue while exporting GNO Dataset from DOMO to NAS Drive')
        print('======================FAILED EXPORTING GNO file ====================')
		
    try:
        DD_id='18b31668-efba-4362-8d10-b12dc0ef9ab3'
        if DD_Err == 0:
            DD_Output='Z:\divvydose (DD)\DOMO\output\DOMO_'+DD_Inp_FileName[0]
            output = domo.ds_get(DD_id)
            output.to_excel(DD_Output,index=False)
            print('======================Exporting DD file complete====================')
            Export_Files_Count = Export_Files_Count + 1
            Success_Email_Message = Success_Email_Message + '\n\n'+'DOMO_' + DD_Inp_FileName[0]
        if DD_Err == 2:
            Export_Files_Count = Export_Files_Count + 1
    except Exception as E:
        Email_Message = Email_Message + '\n\n DD Output file Export Error: \n\n' + str(E)
        print('Issue while exporting DD Dataset from DOMO to NAS Drive')
        print('======================FAILED EXPORTING DD file ====================')

    try:
        SCA_id='7619cdb7-e683-467b-8ff0-857d25cc6e45'
        if SCA_Err == 0:
            SCA_Output='Z:\Surgical Care Affiliates (SCA)\DOMO\output\DOMO_'+SCA_Inp_FileName[0]
            output = domo.ds_get(SCA_id)
            output.to_excel(SCA_Output,index=False)
            print('======================Exporting SCA file complete====================')
            Export_Files_Count = Export_Files_Count + 1
            Success_Email_Message = Success_Email_Message + '\n\n'+'DOMO_' + SCA_Inp_FileName[0]
        if SCA_Err == 2:
            Export_Files_Count = Export_Files_Count + 1
    except Exception as E:
        Email_Message = Email_Message + '\n\n SCA Output file Export Error: \n\n' + str(E)
        print('Issue while exporting SCA Dataset from DOMO to NAS Drive')
        print('======================FAILED EXPORTING SCA file ====================')
###
    # try:
    #     SCAD_id='b6c99a67-ed07-4f59-9288-3ec85801a9fa'
    #     if SCAD_Err == 0:
    #         SCAD_Output='Z:\Surgical Care Affiliates (SCA)\DOMO\output\DOMO_'+SCAD_Inp_FileName[0]
    #         output = domo.ds_get(SCAD_id)
    #         output.to_excel(SCAD_Output,index=False)
    #         print('======================Exporting SCAD file complete====================')
    #         Export_Files_Count = Export_Files_Count + 1
    #         Success_Email_Message = Success_Email_Message + '\n\n'+'DOMO_' + SCAD_Inp_FileName[0]
    #     if SCAD_Err == 2:
    #         Export_Files_Count = Export_Files_Count + 1
    # except Exception as E:
    #     Email_Message = Email_Message + '\n\n SCAD Output file Export Error: \n\n' + str(E)
    #     print('Issue while exporting SCAD Dataset from DOMO to NAS Drive')
    #     print('======================FAILED EXPORTING SCAD file ====================')

    # try:
    #     SSD_id='0777c29c-50e1-4c74-836f-5c06afbc1f66'
    #     if SSD_Err == 0:
    #         SSD_Output='Z:\SmartSheet (SS)\DOMO\output\DOMO_'+SSD_Inp_FileName[0]
    #         output = domo.ds_get(SSD_id)
    #         output.to_csv(SSD_Output,index=False)
    #         print('======================Exporting SSD file complete====================')
    #         Export_Files_Count = Export_Files_Count + 1
    #         Success_Email_Message = Success_Email_Message + '\n\n'+'DOMO_' + SSD_Inp_FileName[0]
    #     if SSD_Err == 2:
    #         Export_Files_Count = Export_Files_Count + 1
    # except Exception as E:
    #     Email_Message = Email_Message + '\n\n SSD Output file Export Error: \n\n' + str(E)
    #     print('Issue while exporting SSD Dataset from DOMO to NAS Drive')
    #     print('======================FAILED EXPORTING SSD file ====================')
###
    print('Export of output datasets completed successfully')
    print('Sending Email')
    smtpobj=smtplib.SMTP('mail25.uhc.com')
    sender='rizwan.syedali@optum.com'
    #receivers=['rizwan.syedali@optum.com','salman_ahmed@optum.com','srijan_joshi@optum.com','jeremy.dorsch@optum.com']
    receivers=['rizwan.syedali@optum.com']

    #if len(Email_Message) > 1:
    if Export_Files_Count == 0 :
        smtpobj.sendmail(sender,receivers,'Subject:ERROR Step 2 Cority Output file generation failed\n\n'+Email_Message)
    else:
        #if DD_Err==2 and PC_Err==2 and OMG_Err==2 and GNO_Err==2 and SS_Err==2 and SCA_Err==2 and SSD_Err==2 and SCAD_Err==2
        if DD_Err==2 and PC_Err==2 and OMG_Err==2 and GNO_Err==2 and SS_Err==2 and SCA_Err==2:
            smtpobj.sendmail(sender,receivers,'Subject:SUCCESS Step 2 Cority Output File generation complete\n\n'+'No input files to generate ouput')
        else:
            smtpobj.sendmail(sender,receivers,'Subject:SUCCESS Step 2 Cority Output File generation complete\n\n'+Success_Email_Message)
    print('Batch Successful, window will close in 60 sec')
    time.sleep(60)

except Exception as E:
    print('Exception Caught:' + str(E))
    Email_Message = Email_Message + '\n\n Parameter assigning Error: \n\n' + str(E)
    smtpobj=smtplib.SMTP('mail25.uhc.com')
    sender='rizwan.syedali@optum.com'
    #receivers=['rizwan.syedali@optum.com','salman_ahmed@optum.com','srijan_joshi@optum.com','jeremy.dorsch@optum.com']
    receivers=['rizwan.syedali@optum.com']
    
    smtpobj.sendmail(sender,receivers,'Subject:ERROR Step 2 Cority Output file generation failed\n\n'+Email_Message)

    time.sleep(120)
