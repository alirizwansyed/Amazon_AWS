from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.common.keys import Keys
import csv
from datetime import datetime
import os 
from selenium import webdriver
from urllib3.exceptions import MaxRetryError
from urllib3.exceptions import ProtocolError
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

URL='https://www.amazon.in'
driverpath = r"C:\ProgramData\chromedriver_81\chromedriver.exe"
chromeOptions = webdriver.ChromeOptions()
chromeOptions.add_experimental_option('useAutomationExtension', True) 
completed_lst=[]

def search_keyword_available_products(search_lst,search_rnk_lst,opfilename):
  driver = webdriver.Chrome(executable_path=driverpath,chrome_options=chromeOptions)
  driver.get(URL)
  driver.maximize_window()
  
  products_num_lst=[]
  keywords_url_lst=[]
  counter=1
  for dsli in search_lst:
    print("Row number ",counter)
    counter=counter+1
    try:
      driver.get(URL)
      driver.find_element_by_id('twotabsearchtextbox').click()
      driver.find_element_by_id('twotabsearchtextbox').clear()
      driver.find_element_by_id('twotabsearchtextbox').send_keys(dsli.strip(' '))
      driver.find_element_by_id('twotabsearchtextbox').send_keys(Keys.ENTER)  
       
      ## testing code
      lang_xpath='//*[@id="search"]/span/div/span/h1/div/div[1]/div/div/span[1]'
      timeout = 20
      try:
          element_present = EC.presence_of_element_located(
              (By.XPATH, lang_xpath))
          WebDriverWait(driver, timeout).until(element_present)
          products_num=driver.find_element_by_xpath('//*[@id="search"]/span/div/span/h1/div/div[1]/div/div/span[1]').text#.split('over ')[-1].split('results')[0].strip(' ').replace(',','')
          #print(products_num)
          #products_num_lst.append(products_num.split('of')[-1].strip(' '))
          products_num_lst.append(products_num)
      except TimeoutException:
          products_num_lst.append('')
      keywords_url_lst.append((driver.current_url))  
      # testing code 
    except Exception as e:
      print(str(e))
      products_num_lst.append('')
      keywords_url_lst.append("")  
  driver.close()
  df=pd.DataFrame()  
  df['Rank']=search_rnk_lst
  df['Keywords']=search_lst
  df['Number Of Products']=products_num_lst
  df['URL']=keywords_url_lst
  if os.path.exists(opfilename):  
    df.to_csv(opfilename,index=False,mode='a')
  else:
    df.to_csv(opfilename,index=False)

df=pd.read_csv(r"D:\DOMO\Syed_Testing\Step4_Input_forPythonScript20210608-120823AM.csv")
search_lst=df['Search Term']
search_rank=df['Search Frequency Rank']
opfilename='D:/DOMO/Syed_Testing/Python_SearchTerm_Output'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+'.csv'
c=0
c_100=c+100
while True:
  if c_100 < len(search_lst):
    search_keyword_available_products(search_lst[c:c_100],search_rank[c:c_100],opfilename)
    c=c_100
    c_100=c+100
  else:
    search_keyword_available_products(search_lst[c:len(search_lst)],search_rank[c:len(search_lst)],opfilename)
    break
    

