#from pydomo import Domo
import pandas
from datetime import datetime
import os
import time
import smtplib





dt_str=str(datetime.now().strftime('%Y%m%d%H%M%S'))

Email_Message = ''
Success_Email_Message='Output files of ORX Sharepoint successfully generated'
Export_Files_Count = 0

try:
    print('Starting execution of scripts')

    
## FCB Scrum Teams File Generation
    try:
        print('FCB Scrum Teams File Generation')
        os.system("python "+'"'+"E:\\ORxTech\\Scripts\\Sharepoint_FCBScrumTeams.py"+'"')
    except Exception as E:
        Email_Message = Email_Message + '\n\n FCB Scrum Teams File Generation Error: \n\n' + str(E)
        
##OptumRxPortfolio File Generation
    try:
        print('OptumRxPortfolio File Generation')
        os.system("python "+'"'+"E:\\ORxTech\\Scripts\\Sharepoint_OptumRxPortfolio2021.py"+'"')
    except Exception as E:
        Email_Message = Email_Message + '\n\n OptumRxPortfolio File Generation Error: \n\n' + str(E)

#ORxBusinessSystems File Generation
    try:
        print('ORxBusinessSystems File Generation')
        os.system("python "+'"'+"E:\\ORxTech\\Scripts\\Sharepoint_ORxBusinessSystems_v1.py"+'"')
    except Exception as E:
        Email_Message = Email_Message + '\n\n ORxBusinessSystems File Generation Error: \n\n' + str(E)

#ORxDepartments File Generation
    try:
        print('ORxDepartments File Generation')
        os.system("python "+'"'+"E:\\ORxTech\\Scripts\\Sharepoint_ORxDepartments.py"+'"')
    except Exception as E:
        Email_Message = Email_Message + '\n\n ORxDepartments File Generation Error: \n\n' + str(E)

#ORxPortfolioLog File Generation
    try:
        print('ORxPortfolioLog File Generation')
        os.system("python "+'"'+"E:\\ORxTech\\Scripts\\Sharepoint_ORxPortfolioLog.py"+'"')
    except Exception as E:
        Email_Message = Email_Message + '\n\n ORxPortfolioLog File Generation Error: \n\n' + str(E)

#ProductLineCommitments File Generation
    try:
        print('ProductLineCommitments File Generation')
        os.system("python "+'"'+"E:\\ORxTech\\Scripts\\Sharepoint_ProductLineCommitments.py"+'"')
    except Exception as E:
        Email_Message = Email_Message + '\n\n ProductLineCommitments File Generation Error: \n\n' + str(E)

#SiteRemediation File Generation
    try:
        print('SiteRemediation File Generation')
        os.system("python "+'"'+"E:\\ORxTech\\Scripts\\Sharepoint_SiteRemediation_v1.py"+'"')
    except Exception as E:
        Email_Message = Email_Message + '\n\n SiteRemediation File Generation Error: \n\n' + str(E)


    print('Execution of scripts completed successfully')
    print('Sending Email')

    smtpobj=smtplib.SMTP('mail25.uhc.com')
    sender='rizwan.syedali@optum.com'
    receivers=['rizwan.syedali@optum.com']
    if len(Email_Message) > 1:    
        smtpobj.sendmail(sender,receivers,'Subject:ERROR OptumRx Scripts Execution failed\n\n'+Email_Message)
    else:
        smtpobj.sendmail(sender,receivers,'Subject:SUCCESS OptumRx Scripts Execution complete\n\n'+Success_Email_Message)

except Exception as E:
    print('Exception Caught:' + str(E))
    Email_Message = Email_Message + '\n\n ORx Execution Scripts Error: \n\n' + str(E)
    smtpobj=smtplib.SMTP('mail25.uhc.com')
    sender='rizwan.syedali@optum.com'
    receivers=['rizwan.syedali@optum.com']    
    smtpobj.sendmail(sender,receivers,'Subject:ERROR OptumRx Scripts Execution failed\n\n'+Email_Message)