from config_extract import *
from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from selenium.webdriver.common.action_chains import ActionChains
from datetime import datetime
from selenium.webdriver.ie.options import Options
from selenium.webdriver.common.keys import Keys
import os
from pathlib import Path

outputdirs={
'Sharepoint_FCBScrumTeams':"E:\\ORxTech\\Output\\FCBScrumTeams\\",
'Sharepoint_OptumRxPortfolio2021':"E:\\ORxTech\\Output\\OptumRxPortfolio2021\\",
'Sharepoint_ORxBusinessSystems':"E:\\ORxTech\\Output\\ORxBusinessSystems\\",
'Sharepoint_ORxDepartments':"E:\\ORxTech\\Output\\ORxDepartments\\",
'Sharepoint_ORxPortfolioLog':"E:\\ORxTech\\Output\\ORxPortfolioLog\\",
'Sharepoint_ProductLineCommitments':"E:\\ORxTech\\Output\\ProductLineCommitments\\",
'Sharepoint_SiteRemediation':"E:\\ORxTech\\Output\\SiteRemediation\\"
}

def form_parent_div():
    return '//*[@id="appRoot"]/div[1]/div[3]/div[3]/div/div[2]/div[2]/div[2]/div[2]/div[1]/div/div/div/div/div/div[3]/div/div/div/div'


def form_header_div():
    return form_parent_div()+'/div[1]/div'

def export_dir(filename):
    return outputdirs[filename]

def login(url):
    config_file_path="C:\\Users\\"+os.environ['USERNAME']+"\\Documents\\"
    driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
    driverpath=read_ini(config_file_path+"config.ini",'chromedriver_path')
    chromeOptions = webdriver.ChromeOptions()
    chromeOptions.binary_location=r"E:\ORxTech\Google\Chrome\Application\chrome.exe"
    chromeOptions.add_experimental_option('useAutomationExtension', False)
    chromeOptions.add_argument('--incognito')
    driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
    driver.get(url)
    time.sleep(15)
    driver.find_element_by_xpath('//*[@id="i0116"]').send_keys(read_ini(config_file_path+"config.ini",'Email'))
    driver.find_element_by_xpath('//*[@id="idSIButton9"]').click()
    ##
    time.sleep(20)
    driver.get('https://cloudfed.unitedhealthgroup.com/idp/9hqPq_LOh71/resume/idp/prp.ping')
    driver.back()
    driver.find_element_by_id('password').send_keys(read_ini(config_file_path+"config.ini",'password'))
    driver.find_element_by_xpath('/html/body/div/div/div/div/div[3]/div[2]/div[1]/div/div/form/div[4]/a[1]').click()
    ##
    return driver