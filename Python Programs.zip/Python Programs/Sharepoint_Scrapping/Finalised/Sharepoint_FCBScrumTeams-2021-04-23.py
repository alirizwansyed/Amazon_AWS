from selenium import webdriver
import pandas as pd
import time
from selenium.webdriver.support.select import Select
import csv
from selenium.webdriver.common.action_chains import ActionChains
from datetime import datetime
from selenium.webdriver.ie.options import Options
from selenium.webdriver.common.keys import Keys
import os
from pathlib import Path
from login import *

# driverpath = "c:\\ProgramData\\ChromeDriver_81\\chromedriver.exe"
# driverpath=read_ini("config.ini",'chromedriver_path')
# chromeOptions = webdriver.ChromeOptions()
# chromeOptions.add_experimental_option('useAutomationExtension', False)
# chromeOptions.add_argument('--incognito')
# driver = webdriver.Chrome(executable_path=driverpath, chrome_options=chromeOptions)
# #driver.get("https://uhgazure.sharepoint.com/sites/orxtech/pfm/Fixed%20Capacity%20Billing%20FCB/Forms/AllItems.aspx")
# driver.get("https://uhgazure.sharepoint.com/sites/orxtech/pfm/_layouts/15/download.aspx?UniqueId=340cd9a7%2De273%2D40e5%2Db2dd%2D603f6958ca71")
# time.sleep(15)
# driver.find_element_by_xpath('//*[@id="i0116"]').send_keys(read_ini("config.ini",'Email'))
# driver.find_element_by_xpath('//*[@id="idSIButton9"]').click()
# ##
# time.sleep(20)
# driver.get('https://cloudfed.unitedhealthgroup.com/idp/9hqPq_LOh71/resume/idp/prp.ping')
# driver.back()
# driver.find_element_by_id('password').send_keys(read_ini("config.ini",'password'))
# driver.find_element_by_xpath('/html/body/div/div/div/div/div[3]/div[2]/div[1]/div/div/form/div[4]/a[1]').click()
# ##

url="https://uhgazure.sharepoint.com/sites/orxtech/pfm/_layouts/15/download.aspx?UniqueId=340cd9a7%2De273%2D40e5%2Db2dd%2D603f6958ca71"
driver=login(url)
time.sleep(30)
paths = sorted(Path("C:\\Users\\"+os.environ['USERNAME']+"\\Downloads").iterdir(), key=os.path.getmtime)

print(paths[-1])
os.system('copy "'+str(paths[-1])+'" "C:\\Users\\'+os.environ['USERNAME']+'\\Documents\\test.xlsx"')
#df.to_csv(r'C:\Users\sali1045\Downloads\SharePoint_OptumRxPortfolio_'+str(datetime.now().strftime('%Y%m%d%H%M%S'))+".csv",index=False,encoding='utf-8')
driver.close()
